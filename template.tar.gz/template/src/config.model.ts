import { BaseServerConfig } from './@steroids/models';

export interface ServerConfig extends BaseServerConfig {

  // Extend config here

}
